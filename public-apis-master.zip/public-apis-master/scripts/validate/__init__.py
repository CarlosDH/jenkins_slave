# -*- coding: utf-8 -*-

from validate import format
from validate import links
